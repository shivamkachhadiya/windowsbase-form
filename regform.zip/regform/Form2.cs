﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace regform
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text!="" && textBox4.Text!="")
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dell\OneDrive\Documents\sdtdb.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                string query1 = "select * from Empinfo where UserName='" + textBox2.Text + "'";
                SqlCommand cmd1 = new SqlCommand(query1, con);
                SqlDataReader sdr = cmd1.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(sdr);

                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("please enter deffrent username...", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
                else
                {

                    string gnd = "";
                    if (radioButton1.Checked)
                    {
                        gnd = radioButton1.Text;
                    }
                    else if (radioButton2.Checked) { gnd = radioButton2.Text; }
                    string dept = comboBox1.Text;
                    string hby = "";
                    if (checkBox1.Checked) { hby += checkBox1.Text; }
                    if (checkBox2.Checked) { hby += checkBox2.Text; }
                    if (checkBox3.Checked) { hby += checkBox3.Text; }
                    if (checkBox4.Checked) { hby += checkBox4.Text; }
                    if (checkBox5.Checked) { hby += checkBox5.Text; }
                    if (checkBox6.Checked) { hby += checkBox6.Text; }
                    string query = "insert into Empinfo values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + gnd + "','" + dept + "','" + hby + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    if (textBox3.Text == textBox4.Text)
                    {
                        cmd.ExecuteNonQuery();
                        DialogResult dr;
                        dr=MessageBox.Show("record registered....", "registred", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if(dr==DialogResult.Yes)
                        {
                            this.Close();

                        }
                    }
                    else
                    {
                        MessageBox.Show("please enter same password...", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    }


                    con.Close();
                }
               
            }
            else
            {
                MessageBox.Show("please enter all details...", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
