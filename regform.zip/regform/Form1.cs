﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace regform
{
    
    public partial class Form1 : Form
    {

        public static DataTable ddd;
        public Form1()
        {
            InitializeComponent();
        }
        public void clear()
        {
            textBox1.Clear();
            textBox2.Clear();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dell\OneDrive\Documents\sdtdb.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            string query = "select * from Empinfo where UserName='" + textBox1.Text + "' AND Password='" + textBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader sdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(sdr);


            if (dt.Rows.Count > 0)
            {

                ddd = dt;
                Form3 f3 = new Form3();
                f3.Show();
                clear();

            }
            else {
                DialogResult dr;
                dr=MessageBox.Show("sorry cant log in", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                if(dr==DialogResult.OK)
                {
                    clear();
                }
            }
        }
    }
}
