﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace regform
{
    public partial class Form3 : Form
    {
        public int selectid;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            dataGridView1.DataSource = Form1.ddd;


        }
  

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectid = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();    
            textBox3.Text= dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox4.Text= dataGridView1.SelectedRows[0].Cells[4].Value.ToString(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Dell\OneDrive\Documents\sdtdb.mdf;Integrated Security=True;Connect Timeout=30");
                con.Open();
                string gnd = "";
                if (radioButton1.Checked) { gnd = radioButton1.Text; }
                else if (radioButton2.Checked) { gnd = radioButton2.Text; }
                string dept = comboBox1.Text;
            string hby = "";
            if (checkBox1.Checked) { hby += checkBox1.Text; }
            if (checkBox2.Checked) { hby += checkBox2.Text; }
            if (checkBox3.Checked) { hby += checkBox3.Text; }
            if (checkBox4.Checked) { hby += checkBox4.Text; }
            if (checkBox5.Checked) { hby += checkBox5.Text; }
            if (checkBox6.Checked) { hby += checkBox6.Text; }
            string query = "update Empinfo set name='" + textBox1.Text + "',UserName='" + textBox2.Text + "',Password='" + textBox3.Text + "',Cpassword='" + textBox4.Text + "',Gender='" + gnd + "',Department='" + dept + "',Hobbies='" + hby + "' where id='" + selectid + "'";
                SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
          
            con.Close();
            MessageBox.Show("record update...","update",MessageBoxButtons.OK,MessageBoxIcon.Information);
           
           
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
        }
    }
}

